package com.aplikasi.toko.response.transaksi

data class Transaksi(
    val id: String,
    val nama: String,
    val tanggal: String,
    val total: String
)