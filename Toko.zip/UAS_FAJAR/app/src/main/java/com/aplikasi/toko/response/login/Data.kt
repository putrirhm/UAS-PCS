package com.aplikasi.toko.response.login

data class Data(
    val admin:Admin,
    val token:String
)
