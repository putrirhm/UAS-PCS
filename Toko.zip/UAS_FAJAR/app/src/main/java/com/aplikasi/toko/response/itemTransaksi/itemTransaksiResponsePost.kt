package com.aplikasi.toko.response.itemTransaksi

data class itemTransaksiResponsePost(
    val `data`: Data,
    val message: String,
    val success: Boolean
)