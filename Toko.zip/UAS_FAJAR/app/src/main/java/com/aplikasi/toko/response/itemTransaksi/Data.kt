package com.aplikasi.toko.response.itemTransaksi

data class Data(
    val item_transaksi: ItemTransaksi
)